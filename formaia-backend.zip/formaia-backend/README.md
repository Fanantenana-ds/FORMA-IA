# FORMA-IA — Backend

API FastAPI unique (architecture monolithique modulaire), conformément au
CDC §6.1. L'IA (Claude + Tavily) est un module de l'application, pas un
service séparé.

## Structure

```
app/
├── main.py              # point d'entrée FastAPI
├── config.py             # configuration (.env)
├── database.py            # SQLAlchemy async (PostgreSQL + pgvector)
├── api/v1/router.py       # agrège les routes de tous les modules
├── clients/
│   └── anthropic_client.py   # client Claude partagé
└── modules/
    ├── auth/           # inscription, connexion, JWT
    ├── users/          # profil utilisateur
    └── ia/             # orchestration Claude, prompts YAML (prompts/m1/)
```

Toutes les routes sont exposées sous `/api/v1/...` (ex: `/api/v1/auth/login`,
`/api/v1/ia/hello-agent`).

## Démarrage avec Docker (recommandé)

```bash
cp .env.example .env
# renseigner ANTHROPIC_API_KEY et TAVILY_API_KEY dans .env

docker compose up -d --build
docker ps          # postgres, redis, backend doivent être "Up"
curl http://localhost:8000/health
```

La doc interactive est disponible sur http://localhost:8000/docs.

## Démarrage en local (sans Docker)

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# adapter DATABASE_URL / REDIS_URL si postgres/redis tournent en local

uvicorn app.main:app --reload
```

## Tester le module IA

Une fois un compte créé et un token obtenu (`/api/v1/auth/register` puis
`/api/v1/auth/login`), l'endpoint `/api/v1/ia/hello-agent` sert de script
de démo : il fait un premier appel réel à Claude pour valider l'intégration.

## Notes

- **Migrations** : `Base.metadata.create_all` est utilisé au démarrage pour
  simplifier le développement. Passer à Alembic avant la mise en production.
- **Frontend** : géré séparément (React/Streamlit) avec son propre
  `Dockerfile.frontend`, non inclus ici.
- **pgvector** : l'extension est activée automatiquement au démarrage ;
  aucune colonne vectorielle n'est encore définie — à ajouter dès qu'un
  module aura besoin de recherche par similarité (ex. base de precedents AO).
