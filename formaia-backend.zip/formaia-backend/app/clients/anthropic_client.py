from anthropic import AsyncAnthropic

from app.config import settings

_client: AsyncAnthropic | None = None


def get_anthropic_client() -> AsyncAnthropic:
    """Client Anthropic partagé (lazy singleton)."""
    global _client
    if _client is None:
        _client = AsyncAnthropic(api_key=settings.anthropic_api_key)
    return _client


async def ask_claude(prompt: str, system: str | None = None, model: str | None = None) -> str:
    """Envoie un prompt à Claude et retourne le texte de la réponse."""
    client = get_anthropic_client()
    response = await client.messages.create(
        model=model or settings.anthropic_model,
        max_tokens=1024,
        system=system or "Tu es un assistant utile.",
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")
