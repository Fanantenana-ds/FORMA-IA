from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Configuration centrale de l'application, lue depuis les variables
    d'environnement / le fichier .env. Un seul point de vérité pour toute
    l'app (auth, base de données, module IA, etc.)."""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- App ---
    app_name: str = "FORMA-IA API"
    api_v1_prefix: str = "/api/v1"
    debug: bool = False

    # --- Base de données (PostgreSQL + pgvector) ---
    database_url: str = "postgresql+asyncpg://formaia:formaia@localhost:5432/formaia"

    # --- Redis (cache / sessions) ---
    redis_url: str = "redis://localhost:6379/0"

    # --- Auth (JWT) ---
    jwt_secret_key: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60

    # --- Module IA ---
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-5"
    tavily_api_key: str = ""


settings = Settings()
