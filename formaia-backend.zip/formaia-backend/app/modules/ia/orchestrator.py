from app.clients.anthropic_client import ask_claude


async def run_hello_agent() -> str:
    """Premier appel de vérification ('hello agent') pour valider que
    l'intégration Claude fonctionne de bout en bout."""
    return await ask_claude(
        prompt="Réponds uniquement par « Agent FORMA-IA opérationnel. » pour confirmer la connexion.",
    )
