from fastapi import APIRouter, Depends

from app.modules.auth.dependencies import get_current_user
from app.modules.auth.models import User
from app.modules.ia.orchestrator import run_hello_agent
from app.modules.ia.schemas import HelloAgentResponse

router = APIRouter(prefix="/ia", tags=["ia"])


@router.get("/hello-agent", response_model=HelloAgentResponse)
async def hello_agent(current_user: User = Depends(get_current_user)):
    """Endpoint de démo : vérifie que l'appel à l'API Claude fonctionne."""
    message = await run_hello_agent()
    return HelloAgentResponse(message=message)
