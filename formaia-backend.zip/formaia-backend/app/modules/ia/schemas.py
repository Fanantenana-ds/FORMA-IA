from pydantic import BaseModel


class HelloAgentResponse(BaseModel):
    message: str
